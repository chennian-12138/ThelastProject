// 创建一个路由器，并暴露出去

// 第一步：引入createrRouter
import { createRouter,createWebHashHistory,createWebHistory } from 'vue-router';
// import { routes } from "vue-router/auto-routes";
// 引入可能要使用的组件
import home from '@/pages/home.vue';
import bot_test from "@/pages/bot_test.vue";
import about_ourselves from "@/pages/about_ourselves.vue";
import history from "@/pages/history.vue";


// 第二步：创建路由器
const router = createRouter({
    history:createWebHashHistory(),
    // history模式的路径更加美观，没有#的存在，更接近传统的url
    // hash模式更加稳妥，美观我们不care
    routes:[
        {name:'firstPage',path:'/home',component:home,},
        {name:'secondPage',path:'/Bot_test',component:bot_test},
        {name:'thirdPage',path:'/About_ourselves',component:about_ourselves},
        {name:'forthPage',path:'/History',component:history},
        {path:"/",redirect:"/home"}
        // 重定向，让指定的路径重定向到另一个路径
    ]
})

export default router