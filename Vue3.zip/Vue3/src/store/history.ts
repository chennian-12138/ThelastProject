import { defineStore } from "pinia";
// 定义一个仓库

