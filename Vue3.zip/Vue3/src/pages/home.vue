<template>
    <!-- <div class="user_picture">
        <img src="用户头像，从数据库调取" alt="">
    </div> -->
</template>

<script set ip lang = 'ts' name = 'home'>
</script>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    list-style: none;
    text-decoration: none;
}
</style>